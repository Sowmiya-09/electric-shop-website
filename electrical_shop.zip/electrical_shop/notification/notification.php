<?php
require "config.php";

// Fetch products with quantity less than their respective threshold values
$sql = "SELECT * FROM product_details WHERE quantity < threshold_quantity";
$result = $con->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Product Quantity Notification</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body>
<div class="container">
    <h2>Product Quantity Notification</h2>
    <table class="table">
        <thead>
        <tr>
            <th>Product Name</th>
            <th>Current Quantity</th>
            <th>Threshold Quantity</th>
            <th>Notification</th>
        </tr>
        </thead>
        <tbody>
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $productName = $row["product_name"];
                $currentQuantity = $row["quantity"];
                $thresholdQuantity = $row["threshold_quantity"];

                // Check if current quantity is below the threshold
                if ($currentQuantity < $thresholdQuantity) {
                    $notification = "<span class='badge badge-warning'>Low Quantity</span>";
                } else {
                    $notification = ""; // No notification
                }

                // Display product details and notification
                echo "<tr>";
                echo "<td>$productName</td>";
                echo "<td>$currentQuantity</td>";
                echo "<td>$thresholdQuantity</td>";
                echo "<td>$notification</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='4'>No products with low quantity.</td></tr>";
        }
        ?>
        </tbody>
    </table>
</div>
</body>
</html>
