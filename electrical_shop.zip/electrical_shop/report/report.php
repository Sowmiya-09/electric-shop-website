<?php
require "config.php";

// Initialize variables
$startDate = date('Y-m-01'); // Default start date: First day of the current month
$endDate = date('Y-m-t'); // Default end date: Last day of the current month
$message = "";

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get start and end dates from the form
    $startDate = $_POST["start_date"];
    $endDate = $_POST["end_date"];

    // SQL query to fetch sales data within the selected time period
    $sql = "SELECT ip.PNAME, SUM(ip.QTY) AS total_sold
            FROM invoice i
            JOIN invoice_products ip ON i.SID = ip.SID
            WHERE i.INVOICE_DATE BETWEEN '$startDate' AND '$endDate'
            GROUP BY ip.PNAME
            ORDER BY total_sold DESC"; // Order by total_sold in descending order
    $result = $con->query($sql);

    if ($result->num_rows == 0) {
        $message = "No sales recorded for the selected time period.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Monthly Sales Report</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body>
<div class="container">
    <h2>Monthly Sales Report</h2>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <div class="form-group row">
            <label for="start_date" class="col-sm-2 col-form-label">Start Date:</label>
            <div class="col-sm-4">
                <input type="date" class="form-control" id="start_date" name="start_date" value="<?php echo $startDate; ?>" required>
            </div>
        </div>
        <div class="form-group row">
            <label for="end_date" class="col-sm-2 col-form-label">End Date:</label>
            <div class="col-sm-4">
                <input type="date" class="form-control" id="end_date" name="end_date" value="<?php echo $endDate; ?>" required>
            </div>
        </div>
        <div class="form-group row">
            <div class="col-sm-4">
                <button type="submit" class="btn btn-primary">Generate Report</button>
            </div>
        </div>
    </form>
    <br>
    <div>
        <?php
        if ($message != "") {
            echo "<div class='alert alert-info'>" . $message . "</div>";
        }
        ?>
    </div>
    <table class="table">
        <thead>
        <tr>
            <th>Product Name</th>
            <th>Total Sold</th>
        </tr>
        </thead>
        <tbody>
        <?php
        if (isset($result) && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row["PNAME"] . "</td>";
                echo "<td>" . $row["total_sold"] . "</td>";
                echo "</tr>";
            }
        }
        ?>
        </tbody>
    </table>
</div>
</body>
</html>
